package com.securegsi

import android.content.Context
import android.os.ParcelFileDescriptor
import android.system.Os
import java.io.File
import java.io.FileOutputStream

object RustBridge {

    private const val BOOTSTRAP_ASSET =
        "bootstrap/securegsi-bootstrap"

    private const val BOOTSTRAP_DIR =
        "bootstrap"

    private const val BOOTSTRAP_FILE =
        "securegsi-bootstrap"

    init {
        System.loadLibrary("rust")
    }

    private external fun sha256Fd(
        fd: Int
    ): String?

    private external fun readHeader(
        fd: Int
    ): String?

    private external fun testContainerRuntimeNative(): String?

    private external fun startGuestProbeNative(): String?

    private external fun stopGuestNative(): String?

    private external fun guestStatusNative(): String?

    private external fun enableNoNewPrivsNative(): String?

    fun sha256(
        fileDescriptor: ParcelFileDescriptor
    ): String {
        return sha256Fd(fileDescriptor.fd)
            ?: throw IllegalStateException(
                "Rust SHA-256 failed"
            )
    }

    fun readHeader(
        fileDescriptor: ParcelFileDescriptor
    ): String {
        return readHeader(fileDescriptor.fd)
            ?: throw IllegalStateException(
                "Rust header read failed"
            )
    }

    fun testContainerRuntime(): String {
        return testContainerRuntimeNative()
            ?: "Rust runtime test failed"
    }

    /**
     * Enables Linux PR_SET_NO_NEW_PRIVS for the current process
     * through the Rust/JNI bridge and verifies the result natively.
     *
     * This does NOT install our own seccomp filter yet.
     */
    fun enableNoNewPrivs(): String {
        return enableNoNewPrivsNative()
            ?: "PR_SET_NO_NEW_PRIVS JNI call failed"
    }

    /**
     * Copies the ARM64 SecureGSI bootstrap from APK assets
     * into the app-private files directory.
     *
     * Resulting path:
     * /data/data/com.securegsi/files/bootstrap/securegsi-bootstrap
     */
    fun prepareBootstrap(
        context: Context
    ): File {
        val appContext =
            context.applicationContext

        val bootstrapDir =
            File(
                appContext.filesDir,
                BOOTSTRAP_DIR
            )

        if (!bootstrapDir.exists()) {
            check(bootstrapDir.mkdirs()) {
                "Failed to create bootstrap directory: " +
                        bootstrapDir.absolutePath
            }
        }

        val bootstrapFile =
            File(
                bootstrapDir,
                BOOTSTRAP_FILE
            )

        /*
         * Always replace the extracted binary.
         * This avoids accidentally running an older bootstrap
         * after installing a newer SecureGSI APK.
         */
        appContext.assets
            .open(BOOTSTRAP_ASSET)
            .use { input ->

                FileOutputStream(
                    bootstrapFile,
                    false
                ).use { output ->

                    input.copyTo(output)

                    output.flush()

                    output.fd.sync()
                }
            }

        /*
         * 0700 in decimal = 448.
         * Owner can read/write/execute.
         * Nobody else receives permissions.
         */
        Os.chmod(
            bootstrapFile.absolutePath,
            448
        )

        check(
            bootstrapFile.exists()
        ) {
            "Bootstrap extraction failed"
        }

        check(
            bootstrapFile.length() > 0L
        ) {
            "Bootstrap is empty"
        }

        return bootstrapFile
    }

    /**
     * Prepares the bootstrap first, then starts the Rust
     * supervisor/payload runtime.
     */
    fun startGuestProbe(
        context: Context
    ): String {
        val bootstrap =
            prepareBootstrap(context)

        check(
            bootstrap.canExecute()
        ) {
            "Bootstrap is not executable: " +
                    bootstrap.absolutePath
        }

        return startGuestProbeNative()
            ?: "Guest runtime failed"
    }

    /**
     * Kept temporarily for compatibility with existing code.
     *
     * Prefer startGuestProbe(context), because the bootstrap
     * must be extracted before the guest is started.
     */
    fun startGuestProbe(): String {
        return startGuestProbeNative()
            ?: "Guest runtime failed"
    }

    fun stopGuest(): String {
        return stopGuestNative()
            ?: "Failed to stop guest"
    }

    fun guestStatus(): String {
        return guestStatusNative()
            ?: "SecureGSI Guest Runtime\nStatus: UNKNOWN"
    }
}