package com.securegsi

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.Process
import android.util.Log
import java.io.File

class AegisIsolatedService : Service() {

    companion object {
        const val DESCRIPTOR =
            "com.securegsi.AegisIsolatedService"

        const val TRANSACTION_GET_IDENTITY =
            IBinder.FIRST_CALL_TRANSACTION

        private const val TAG =
            "Aegis-Isolated"
    }

    private val binder = object : Binder() {

        override fun onTransact(
            code: Int,
            data: Parcel,
            reply: Parcel?,
            flags: Int
        ): Boolean {

            if (code == TRANSACTION_GET_IDENTITY) {
                data.enforceInterface(DESCRIPTOR)

                reply?.writeNoException()
                reply?.writeInt(Process.myPid())
                reply?.writeInt(Process.myUid())

                return true
            }

            return super.onTransact(
                code,
                data,
                reply,
                flags
            )
        }
    }

    override fun onCreate() {
        super.onCreate()

        Log.i(
            TAG,
            "started pid=${Process.myPid()} uid=${Process.myUid()}"
        )

        try {
            val selinuxContext =
                File("/proc/self/attr/current")
                    .readText()
                    .trim()

            Log.i(
                TAG,
                "SELinux=$selinuxContext"
            )

            val statusBefore =
                readSecurityStatus()

            Log.i(
                TAG,
                "STATUS_BEFORE=$statusBefore"
            )

            val noNewPrivsResult =
                RustBridge.enableNoNewPrivs()

            Log.i(
                TAG,
                "NNP_RESULT=$noNewPrivsResult"
            )

            val statusAfter =
                readSecurityStatus()

            Log.i(
                TAG,
                "STATUS_AFTER=$statusAfter"
            )
        } catch (e: Throwable) {
            Log.e(
                TAG,
                "security probe failed",
                e
            )
        }
    }

    private fun readSecurityStatus(): String {
        return File("/proc/self/status")
            .readLines()
            .filter { line ->
                line.startsWith("Uid:") ||
                        line.startsWith("Gid:") ||
                        line.startsWith("Groups:") ||
                        line.startsWith("CapInh:") ||
                        line.startsWith("CapPrm:") ||
                        line.startsWith("CapEff:") ||
                        line.startsWith("CapBnd:") ||
                        line.startsWith("NoNewPrivs:") ||
                        line.startsWith("Seccomp:")
            }
            .joinToString(" | ")
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }
}
